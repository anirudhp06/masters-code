﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace Partb2
{
    public partial class Letter : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@" Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Admin\Documents\psm.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("insert into AreaLetters(IdLetters,LetterAddress,IdArea) values('" + txtLetterId.Text + "','" + txtLetterAddress.Text + "','" + txtAreaId.Text + "')", con);
            sda.SelectCommand.ExecuteNonQuery();
            con.Close();
            Response.Write("<script>alert('Inserted into the AreaLetters Database.Thank You')</script>");

        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtLetterId.Text = "";
            txtLetterAddress.Text = "";
            txtAreaId.Text = "";

        }

        protected void btnDisplay_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select * from AreaLetters", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
            con.Close();
        }
    }
}