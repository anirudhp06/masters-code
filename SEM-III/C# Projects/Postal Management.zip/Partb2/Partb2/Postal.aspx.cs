﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace Partb2
{
    public partial class Postal : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@" Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Admin\Documents\psm.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("insert into postmanDetails(idPostMan,postmanName,contactNumber,idArea) values('" + txtPid.Text + "','" + txtPname.Text + "','" + txtContact.Text + "','" + txtAreaId.Text + "')", con);
            sda.SelectCommand.ExecuteNonQuery();
            con.Close();
            Response.Write("<script>alert('Postman details added successfully...')</script>");

        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtPid.Text = "";
            txtPname.Text = "";
            txtContact.Text = "";
            txtAreaId.Text = "";
        }

        protected void btnDisplay_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select * from postmanDetails", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            GridView1.DataBind();
            con.Close();

        }

       
    }
}